
def load_predefined(predefined_filename):
    matching_count = {}
    print_words = {}
    with open(predefined_filename, 'r') as file:
        line = file.readline()
        while line:
            line = line.strip()
            word = line.lower()
            matching_count[word] = 0
            print_words[word] = line
            line = file.readline()

    return matching_count, print_words

def remove_punctuations(word):
    # Assume a word always starts and ends with t a-z or 0-9. Anything else is a punctuation.
    i = 0
    while i < len(word) and not word[i].isalpha() and not word[i].isnumeric():
        i += 1

    j = len(word) - 1
    while j > i and not word[j].isalpha() and not word[j].isnumeric():
        j -= 1

    return word[i:j + 1]

def update_matching_count(matching_count, input_filename):
    with open(input_filename, 'r') as file:
        line = file.readline()
        while line:
            line = line.strip()
            for word in line.split(" "):
                word = remove_punctuations(word).lower()
                if word in matching_count:
                    matching_count[word] += 1

            line = file.readline()


def pretty_print(matching_count, print_words):
    print("Predefined word / Match count")
    for m, c in matching_count.items():
        print(f"{print_words[m]}  {c}")


def run(predefined_filename, input_filename):
    matching_count, print_words = load_predefined(predefined_filename)
    update_matching_count(matching_count, input_filename)
    pretty_print(matching_count, print_words)


if __name__ == '__main__':
    run("test1_predefined.txt", "test1_input.txt")
